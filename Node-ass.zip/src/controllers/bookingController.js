const Slot = require('../models/Slot');
const Booking = require('../models/Booking');
const User = require('../models/User');

exports.getAvailableSlots = async (req, res) => {
  const slots = await Slot.find({ isBooked: false });
  res.json(slots);
};

exports.bookSlot = async (req, res) => {
  const { slotId } = req.body;
  const slot = await Slot.findById(slotId);
  if (!slot || slot.isBooked) return res.status(400).json({ message: 'Slot not available' });

  const user = await User.findById(req.user.id);
  if (user.wallet < 200) return res.status(400).json({ message: 'Insufficient balance' });

  user.wallet -= 200;
  await user.save();
  slot.isBooked = true;
  await slot.save();

  const booking = new Booking({ memberId: user._id, trainerId: slot.trainerId, slotId });
  await booking.save();

  console.log(`Email sent to ${user.email} confirming session booking.`);

  res.json({ message: 'Booking confirmed' });
};

exports.getTrainerBookings = async (req, res) => {
  const bookings = await Booking.find({ trainerId: req.user.id });
  res.json(bookings);
};
