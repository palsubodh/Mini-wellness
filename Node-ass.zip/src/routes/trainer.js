const express = require('express');
const { addSlot, getMySlots } = require('../controllers/trainerController');
const router = express.Router();

router.post('/add-slot', addSlot);
router.get('/my-slots', getMySlots);

module.exports = router;