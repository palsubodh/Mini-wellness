const express = require('express');
const { getAvailableSlots, bookSlot, getTrainerBookings } = require('../controllers/bookingController');
const router = express.Router();

router.get('/slots', getAvailableSlots);
router.post('/book', bookSlot);
router.get('/my-bookings', getTrainerBookings);

module.exports = router;