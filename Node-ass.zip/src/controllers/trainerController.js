const Slot = require('../models/Slot');

exports.addSlot = async (req, res) => {
  const { date, time } = req.body;
  const slot = new Slot({ trainerId: req.user.id, date, time });
  await slot.save();
  res.status(201).json({ message: 'Slot added' });
};

exports.getMySlots = async (req, res) => {
  const slots = await Slot.find({ trainerId: req.user.id });
  res.json(slots);
};