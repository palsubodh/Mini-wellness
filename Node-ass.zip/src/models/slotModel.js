const mongoose = require('mongoose');

const slotSchema = new mongoose.Schema({
  trainerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  date: String,
  time: String,
  isBooked: { type: Boolean, default: false }
});

module.exports = mongoose.model('Slot', slotSchema);
