const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const authRoutes = require('./routes/auth');
const trainerRoutes = require('./routes/trainer');
const bookingRoutes = require('./routes/booking');
const { authenticate } = require('./middleware/auth');

dotenv.config();
const app = express();

app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/trainer', authenticate, trainerRoutes);
app.use('/api/booking', authenticate, bookingRoutes);

mongoose.connect('mongodb://localhost:27017/wellness', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log('MongoDB connected');
  app.listen(process.env.PORT || 3000, () => {
    console.log('Server running');
  });
});
